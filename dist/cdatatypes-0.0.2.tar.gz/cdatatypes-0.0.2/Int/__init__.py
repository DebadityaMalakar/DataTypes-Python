from .Int2 import *
from .Int4 import *
from .Int8 import *
from .Int16 import *
from .Int32 import *
from .Int64 import *